function Get-Software {
    param()
    # Gets software
}

function Install-Software {
    param()
    # Installs software
}

function Remove-Software {
    param ()
    # Removes software
}