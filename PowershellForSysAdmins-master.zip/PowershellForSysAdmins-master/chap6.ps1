# WRITING FUNCTIONS

Get-Command -CommandType Function

function Install-MySoftware {
    Write-Host 'Your software has been installed.'
}

# Verb-Noun naming convention
Get-Verb
