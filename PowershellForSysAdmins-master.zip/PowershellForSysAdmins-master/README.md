[![GitHub license](https://img.shields.io/badge/license-MIT-green.svg)](https://raw.githubusercontent.com/lotspaih/PowershellForSysAdmins/master/LICENSE) [![Language](https://img.shields.io/badge/language-powershell-blue.svg)](https://github.com/powershell/powershell)

# PowershellForSysAdmins
Powershell for SysAdmins Practice and Project Repository 

From the book ["PowerShell for Sysadmins: Workflow Automation Made Easy"](https://nostarch.com/powershellsysadmins) by [Adam Bertram](https://github.com/adbertram/PowerShellForSysadmins)
