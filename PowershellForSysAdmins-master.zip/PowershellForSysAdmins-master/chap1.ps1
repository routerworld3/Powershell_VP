Verb-Noun

Get-Command -Name*

Command-Name [tab for completions]

Get-Alias

Get-Help CommandName -Examples
Get-Help CommandName -Detailed
Get-Help CommandName* - Full

Get-Help - Name About*

Update-Help
