# TESTING WITH PESTER

# extension .Tests.ps1

#Format Structure
describe
    context
        it
            assertions
            
# See Sample.Tests.ps1 file for example

Invoke-Pester -Path 'c:\Sample.Tests.ps1'
